# Weather Analysis & Report Generation

## Objective
Build a Python CLI tool that:
- Fetches weather data for a list of cities
- Stores it in a local file (CSV or JSON)
- Analyzes the data to provide basic insights
- Outputs a clean, formatted report file

## How to Run
1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Add your city names to `cities.txt` (one city per line).

3. Run the CLI:
```bash
python weather_cli.py --input cities.txt --output weather_data.json --report summary_report.txt
```

4. Run Unit Tests:
```bash
pytest tests/
```

## Assumptions
- Cities are correctly spelled in the input file.
- The API key from OpenWeatherMap is valid.

## Output Files
- weather_data.json
- summary_report.txt
- temperature_chart.png
