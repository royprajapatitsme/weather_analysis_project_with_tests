import os
import json
import weather_cli

def test_read_cities():
    test_file = 'test_cities.txt'
    with open(test_file, 'w') as f:
        f.write('Delhi\nMumbai\n')

    cities = weather_cli.read_cities(test_file)
    assert cities == ['Delhi', 'Mumbai']
    os.remove(test_file)

def test_save_and_load_data():
    data = [{'city': 'Delhi', 'temperature': 30, 'humidity': 50, 'weather': 'clear sky', 'wind_speed': 3}]
    file_name = 'test_weather.json'
    weather_cli.save_data(data, file_name)

    with open(file_name, 'r') as f:
        loaded_data = json.load(f)

    assert loaded_data == data
    os.remove(file_name)

def test_generate_report():
    data = [
        {'city': 'Delhi', 'temperature': 30, 'humidity': 50, 'weather': 'clear sky', 'wind_speed': 3},
        {'city': 'Shimla', 'temperature': 10, 'humidity': 60, 'weather': 'rain', 'wind_speed': 2}
    ]
    report_file = 'test_report.txt'
    weather_cli.generate_report(data, report_file)

    assert os.path.exists(report_file)
    os.remove(report_file)
