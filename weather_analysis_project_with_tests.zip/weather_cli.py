import requests
import json
import argparse
import matplotlib.pyplot as plt
import os

API_KEY = 'YOUR_API_KEY'  # Replace with your OpenWeatherMap API key
BASE_URL = 'http://api.openweathermap.org/data/2.5/weather'


def fetch_weather(city):
    params = {'q': city, 'appid': API_KEY, 'units': 'metric'}
    response = requests.get(BASE_URL, params=params)
    if response.status_code == 200:
        data = response.json()
        return {
            'city': city,
            'temperature': data['main']['temp'],
            'humidity': data['main']['humidity'],
            'weather': data['weather'][0]['description'],
            'wind_speed': data['wind']['speed']
        }
    else:
        return None


def read_cities(file_path):
    with open(file_path, 'r') as file:
        cities = [line.strip() for line in file.readlines() if line.strip()]
    return cities


def save_data(data, output_file):
    with open(output_file, 'w') as file:
        json.dump(data, file, indent=4)


def generate_report(data, report_file):
    if not data:
        print("No valid weather data to analyze.")
        return

    highest = max(data, key=lambda x: x['temperature'])
    lowest = min(data, key=lambda x: x['temperature'])
    avg_temp = sum(d['temperature'] for d in data) / len(data)

    clear_weather_cities = [d['city'] for d in data if 'clear' in d['weather'].lower()]
    rain_cities = [d['city'] for d in data if 'rain' in d['weather'].lower()]

    report_lines = [
        "Weather Summary Report",
        f"Cities Processed: {len(data)}",
        "",
        f"Highest Temperature: {highest['temperature']}°C - {highest['city']}",
        f"Lowest Temperature: {lowest['temperature']}°C - {lowest['city']}",
        f"Average Temperature: {avg_temp:.1f}°C",
        "",
        f"Clear Weather Cities: {len(clear_weather_cities)}",
        *clear_weather_cities,
        "",
        f"Rain in Cities: {len(rain_cities)}",
        *rain_cities
    ]

    with open(report_file, 'w') as file:
        file.write('\n'.join(report_lines))

    print('\n'.join(report_lines))


def plot_temperatures(data, output_path='temperature_chart.png'):
    cities = [d['city'] for d in data]
    temperatures = [d['temperature'] for d in data]

    plt.figure(figsize=(12, 6))
    plt.bar(cities, temperatures, color='skyblue')
    plt.xlabel('Cities')
    plt.ylabel('Temperature (°C)')
    plt.title('Temperature Comparison of Cities')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    print(f"Temperature chart saved as {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Weather Analysis CLI Tool")
    parser.add_argument('--input', type=str, default='cities.txt', help='Path to input cities file')
    parser.add_argument('--output', type=str, default='weather_data.json', help='Path to save weather data')
    parser.add_argument('--report', type=str, default='summary_report.txt', help='Path to save summary report')

    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"Input file {args.input} not found.")
        return

    cities = read_cities(args.input)
    weather_data = []

    for city in cities:
        print(f"Fetching weather for {city}...")
        data = fetch_weather(city)
        if data:
            weather_data.append(data)
        else:
            print(f"Warning: Could not fetch data for {city}.")

    if weather_data:
        save_data(weather_data, args.output)
        generate_report(weather_data, args.report)
        plot_temperatures(weather_data)
    else:
        print("No valid data fetched. Exiting.")


if __name__ == '__main__':
    main()
